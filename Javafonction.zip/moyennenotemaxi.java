public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    float[] notes = new float[35];
    float somme = 0, maxNote = 0;
    for (int i = 0; i < notes.length; i++) {
        System.out.println("Veuillez saisir la note de l'élève n°" + (i + 1) + " :");
        notes[i] = sc.nextFloat();
        somme += notes[i];
        if (notes[i] > maxNote) {
            maxNote = notes[i];
        }
    }
    float moyenne = somme / notes.length;
    System.out.println("La moyenne de la classe est : " + moyenne);
    System.out.println("La meilleure note est : " + maxNote);
    sc.close();
}
