public static void tableMultiplication() {
    Scanner sc = new Scanner(System.in);
    int n, nb, compteur = 1, recommencer;
    do {
        System.out.println("Ecrire un nombre :");
        n = sc.nextInt();
        System.out.println("Jusqu'à combien voulez-vous multiplier ?");
        nb = sc.nextInt();
        System.out.println("Table des " + n);
        do {
            System.out.println(compteur + " * " + n + " = " + (n * compteur));
            compteur++;
        } while (compteur <= nb);
        System.out.println("Voulez-vous relancer le programme ? (oui : 1 / non : 2)");
        recommencer = sc.nextInt();
        compteur = 1;
    } while (recommencer == 1);
    sc.close();
}

public static void main(String[] args) {
    tableMultiplication();
}
