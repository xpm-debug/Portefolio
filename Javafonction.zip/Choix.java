public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    int relancer = 0, choix = 0;
    do {
        System.out.println("Que souhaitez-vous faire (1 : factorielle ; 2 : multiplication) ?");
        choix = sc.nextInt();
        if (choix == 1) {
            factorielle();
        } else if (choix == 2) {
            tableMultiplication();
        } else {
            System.out.println("Erreur, veuillez recommencer.");
        }
        System.out.println("Voulez-vous relancer le programme ? (oui : 1 / non : 2)");
        relancer = sc.nextInt();
    } while (relancer == 1);
    sc.close();
}
