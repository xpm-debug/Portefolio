public static void factorielle() {
    Scanner sc = new Scanner(System.in);
    int nombre, total, recommencer;
    do {
        System.out.println("Entrez un nombre à factoriser :");
        nombre = sc.nextInt();
        total = 1;
        do {
            total *= nombre;
            nombre--;
        } while (nombre > 1);
        System.out.println("Résultat : " + total);
        System.out.println("Voulez-vous relancer le programme ? (oui : 1 / non : 2)");
        recommencer = sc.nextInt();
    } while (recommencer == 1);
    sc.close();
}

public static void main(String[] args) {
    factorielle();
}
