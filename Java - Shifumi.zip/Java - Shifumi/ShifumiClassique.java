import java.util.Scanner;

public class ShifumiClassique {

	public static void main(String[] args) {

		/*
		 * Jeu Shifumi (Pierre-Feuille-Ciseaux) contre l'ordinateur
		 * Règles :
		 * - La feuille bat la pierre
		 * - La pierre bat les ciseaux
		 * - Les ciseaux battent la feuille
		 * - Égalité si les deux choix sont identiques
		 *
		 * Auteur : Xavier Sionnet
		 * Version : 1.0
		 */

		System.out.println("Bienvenue dans le jeu Shifumi !");
		System.out.println("Règles du jeu :");
		System.out.println("- Feuille bat Pierre");
		System.out.println("- Pierre bat Ciseaux");
		System.out.println("- Ciseaux battent Feuille");
		System.out.println("- Égalité si même choix");

		Scanner sc = new Scanner(System.in);

		// Variables de jeu
		int nbpoints;
		char chjoueur;
		char chOrdi;
		int aleatoire;
		int scoreOrdi = 0;
		int scoreJoueur = 0;
		boolean rejouer = true;

		while (rejouer) {

			// Choix du nombre de points
			do {
				System.out.println("À combien de points souhaitez-vous jouer ? (3, 5 ou 10)");
				nbpoints = sc.nextInt();
				System.out.println("Nombre de points choisi : " + nbpoints);
			} while (nbpoints != 3 && nbpoints != 5 && nbpoints != 10);

			// Remise à zéro des scores
			scoreJoueur = 0;
			scoreOrdi = 0;

			// Boucle de jeu
			while (scoreJoueur < nbpoints && scoreOrdi < nbpoints) {

				// Choix du joueur
				do {
					System.out.println("Choisissez votre coup : (p = pierre, f = feuille, c = ciseaux)");
					chjoueur = sc.next().charAt(0);
					chjoueur = Character.toLowerCase(chjoueur);
				} while (chjoueur != 'p' && chjoueur != 'f' && chjoueur != 'c');

				// Génération aléatoire du choix de l'ordinateur
				aleatoire = (int) (Math.random() * 3) + 1;
				if (aleatoire == 1) {
					chOrdi = 'p'; // pierre
				} else if (aleatoire == 2) {
					chOrdi = 'f'; // feuille
				} else {
					chOrdi = 'c'; // ciseaux
				}

				// Annonce du choix de l'ordinateur avec suspense
				System.out.println("L'ordinateur réfléchit à son choix...");
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

				System.out.println("L'ordinateur a choisi : " + chOrdi);

				// Résultat du tour
				if (chjoueur == chOrdi) {
					System.out.println("Égalité !");
				} else if ((chjoueur == 'f' && chOrdi == 'p') ||
						(chjoueur == 'p' && chOrdi == 'c') ||
						(chjoueur == 'c' && chOrdi == 'f')) {
					System.out.println("Vous avez gagné ce tour !");
					scoreJoueur++;
				} else {
					System.out.println("L'ordinateur a gagné ce tour !");
					scoreOrdi++;
				}

				// Affichage du score actuel
				System.out.println("Score actuel : Joueur " + scoreJoueur + " - Ordinateur " + scoreOrdi);
				System.out.println("--------------------------------------------------");
			}

			// Fin de la partie
			if (scoreJoueur == nbpoints) {
				System.out.println(" Félicitations ! Vous avez gagné la partie !");
			} else {
				System.out.println(" L'ordinateur remporte la partie !");
			}

			// Demande à rejouer
			System.out.println("Souhaitez-vous rejouer ? (o = oui / n = non)");
			char reponse = sc.next().charAt(0);
			rejouer = (Character.toLowerCase(reponse) == 'o');
		}

		System.out.println("Merci d'avoir joué à Shifumi !");
		sc.close();
	}
}
