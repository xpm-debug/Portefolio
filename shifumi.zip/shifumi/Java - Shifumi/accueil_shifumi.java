import java.util.Scanner;

public class accueil_shifumi {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Message d'accueil
        System.out.println("==========================================");
        System.out.println("       Bienvenue dans le jeu Shifumi !");
        System.out.println("==========================================");
        System.out.println();
        System.out.println("Souhaitez-vous jouer à la version classique ou avec la variante du puits ?");
        System.out.println("Tapez 'p' pour jouer avec la version puits.");
        System.out.println("Tapez 's' pour jouer à la version standard.");
        System.out.print("Votre choix (p/s) : ");

        char choix = sc.next().charAt(0);
        choix = Character.toLowerCase(choix);

        if (choix == 'p') {
            System.out.println("Lancement de la version avec le puits...");
            Shifumi_puit.main(null); // Appel de la version avec puits
        } else {
            System.out.println("Lancement de la version classique...");
            ShifumiClassique.main(null); // Appel de la version classique
        }

        System.out.println("Merci d'avoir lancé Shifumi !");
        sc.close();
    }
}
