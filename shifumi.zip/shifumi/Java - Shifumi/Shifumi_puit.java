import java.util.Scanner;

public class Shifumi_puit {

	public static void main(String[] args) {

		/*
		 * Version Shifumi avec la variante du puits.
		 * Règles :
		 * - Feuille bat Pierre et Puits
		 * - Pierre bat Ciseaux
		 * - Ciseaux battent Feuille
		 * - Puits bat Pierre et Ciseaux
		 * - Égalité si les deux choix sont identiques
		 */

		Scanner sc = new Scanner(System.in);
		boolean rejouer = true;

		System.out.println("==========================================");
		System.out.println("    Bienvenue dans le Shifumi - Puits !");
		System.out.println("==========================================\n");

		System.out.println("Voici les règles du jeu :");
		System.out.println("- Feuille bat Pierre et Puits");
		System.out.println("- Pierre bat Ciseaux");
		System.out.println("- Ciseaux battent Feuille");
		System.out.println("- Puits bat Pierre et Ciseaux");
		System.out.println("- Égalité si même choix\n");

		while (rejouer) {
			int scoreJoueur = 0;
			int scoreOrdi = 0;
			int nbpoints;
			char chjoueur;
			char chOrdi;

			// Choix du nombre de points
			do {
				System.out.println("À combien de points voulez-vous jouer ? (3, 5 ou 10)");
				nbpoints = sc.nextInt();
				System.out.println("Partie en " + nbpoints + " points.");
			} while (nbpoints != 3 && nbpoints != 5 && nbpoints != 10);

			// Boucle de jeu principale
			while (scoreJoueur < nbpoints && scoreOrdi < nbpoints) {

				// Choix du joueur
				do {
					System.out.println("Choisissez votre coup : pierre (p), feuille (f), ciseaux (c), puits (t)");
					chjoueur = Character.toLowerCase(sc.next().charAt(0));
				} while (chjoueur != 'p' && chjoueur != 'f' && chjoueur != 'c' && chjoueur != 't');

				// Choix de l'ordinateur (aléatoire)
				int aleatoire = (int) (Math.random() * 4) + 1;
				if (aleatoire == 1)
					chOrdi = 'p';
				else if (aleatoire == 2)
					chOrdi = 'f';
				else if (aleatoire == 3)
					chOrdi = 't';
				else
					chOrdi = 'c';

				// Affichage du choix de l'ordinateur avec suspense
				System.out.println("L'ordinateur choisit...");
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				System.out.println("Choix de l'ordinateur : " + chOrdi);

				// Détermination du gagnant
				if (chjoueur == chOrdi) {
					System.out.println("Égalité !");
				} else if ((chjoueur == 'p' && chOrdi == 'c') ||
						(chjoueur == 'f' && (chOrdi == 'p' || chOrdi == 't')) ||
						(chjoueur == 'c' && chOrdi == 'f') ||
						(chjoueur == 't' && (chOrdi == 'p' || chOrdi == 'c'))) {
					System.out.println("Vous avez gagné ce tour !");
					scoreJoueur++;
				} else {
					System.out.println("L'ordinateur a gagné ce tour !");
					scoreOrdi++;
				}

				// Affichage des scores
				System.out.println("Score actuel : Joueur " + scoreJoueur + " - Ordinateur " + scoreOrdi);
				System.out.println("--------------------------------------------------");
			}

			// Fin de la partie
			if (scoreJoueur == nbpoints) {
				System.out.println("🎉 Bravo ! Vous remportez la partie !");
			} else {
				System.out.println("💻 L'ordinateur gagne cette partie !");
			}

			// Demande de rejouer
			System.out.println("Souhaitez-vous rejouer ? (o = oui / n = non)");
			char reponse = sc.next().charAt(0);
			rejouer = (Character.toLowerCase(reponse) == 'o');
			System.out.println();
		}

		System.out.println("Merci d'avoir joué à Shifumi avec puits !");
		sc.close();
	}
}
