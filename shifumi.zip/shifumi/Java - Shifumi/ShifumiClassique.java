import java.util.Scanner;

public class ShifumiClassique {

	public static void main(String[] args) {

		/*
		 * Jeu Shifumi (Pierre-Feuille-Ciseaux) contre l'ordinateur
		 * Règles :
		 * - La feuille bat la pierre
		 * - La pierre bat les ciseaux
		 * - Les ciseaux battent la feuille
		 * - Égalité si les deux choix sont identiques
		 *
		 * Ce fichier contient des commentaires qui indiquent clairement
		 * les étapes demandées dans l'énoncé (Étape 1..Étape 10).
		 * L'objectif est de rendre le code plus propre et compréhensible pour
		 * un élève de BTS SIO 1ère année.
		 */

		System.out.println("Bienvenue dans le jeu Shifumi !");
		System.out.println("Règles du jeu :");
		System.out.println("- Feuille bat Pierre");
		System.out.println("- Pierre bat Ciseaux");
		System.out.println("- Ciseaux battent Feuille");
		System.out.println("- Égalité si même choix");

		Scanner sc = new Scanner(System.in);

		
		// Variables de jeu (initialisation)
		
		int nbpoints;          
		char chjoueur;          
		char chOrdi;            
		int aleatoire;        
		int scoreOrdi = 0;     
		int scoreJoueur = 0;   
		boolean rejouer = true;

		while (rejouer) {

			
			// Étape 1 : Définir le nombre de points
			
			do {
				System.out.println("À combien de points souhaitez-vous jouer ? (3, 5 ou 10)");
				nbpoints = sc.nextInt();
				System.out.println("Nombre de points choisi : " + nbpoints);
			} while (nbpoints != 3 && nbpoints != 5 && nbpoints != 10);

			
			scoreJoueur = 0;
			scoreOrdi = 0;

			
			// Boucle principale des manches (Étape 6)
		
			while (scoreJoueur < nbpoints && scoreOrdi < nbpoints) {

				
				// Étape 2 : Choix du joueur
			
				do {
					System.out.println("Choisissez votre coup : (p = pierre, f = feuille, c = ciseaux)");
					chjoueur = sc.next().charAt(0);
					chjoueur = Character.toLowerCase(chjoueur);
				} while (chjoueur != 'p' && chjoueur != 'f' && chjoueur != 'c');

				// Étape 3 : Choix aléatoire de l'ordinateur
				
				aleatoire = (int) (Math.random() * 3) + 1; // 1..3
				if (aleatoire == 1) {
					chOrdi = 'p'; // pierre
				} else if (aleatoire == 2) {
					chOrdi = 'f'; // feuille
				} else {
					chOrdi = 'c'; // ciseaux
				}

				
				// Étape 4 : Révélation du suspense
				
				System.out.println("L'ordinateur réfléchit à son choix...");
				try {
					Thread.sleep(3000); // pause de 3 secondes (Étape 4)
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

				System.out.println("L'ordinateur a choisi : " + chOrdi);

				
				// Étape 5 : Déterminer le gagnant de la manche et attribuer les points
				
				if (chjoueur == chOrdi) {
					System.out.println("Égalité ! Aucun point attribué.");
				} else if ((chjoueur == 'f' && chOrdi == 'p') ||
							(chjoueur == 'p' && chOrdi == 'c') ||
							(chjoueur == 'c' && chOrdi == 'f')) {
					System.out.println("Vous avez gagné ce tour ! +1 point");
					scoreJoueur++;
				} else {
					System.out.println("L'ordinateur a gagné ce tour ! +1 point");
					scoreOrdi++;
				}

			
				System.out.println("Score actuel : Joueur " + scoreJoueur + " - Ordinateur " + scoreOrdi);
				System.out.println("--------------------------------------------------");
			}

			
			// Étape 7 : Fin de partie
			
			if (scoreJoueur == nbpoints) {
				System.out.println(" Félicitations ! Vous avez gagné la partie !");
			} else {
				System.out.println(" L'ordinateur remporte la partie !");
			}

			// Demande à rejouer (réponse simple o/n)
			System.out.println("Souhaitez-vous rejouer ? (o = oui / n = non)");
			char reponse = sc.next().charAt(0);
			rejouer = (Character.toLowerCase(reponse) == 'o');
		}

		System.out.println("Merci d'avoir joué à Shifumi !");
		sc.close();
	}
}
